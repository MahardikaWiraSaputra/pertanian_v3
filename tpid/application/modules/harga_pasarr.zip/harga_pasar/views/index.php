<!-- BEGIN: Content -->
<div class="content">
                <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
                    <h2 class="text-lg font-medium mr-auto">
                      Informasi Harga Pasar
                    </h2>
                </div>

                <div class="grid grid-cols-12 gap-6 mt-5">
                  <div class="col-span-12 sm:col-span-6 xl:col-span-7 intro-y">
                    <div class="report-box zoom-in">
                      <div class="box p-5">
                        <div class="flex">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-credit-card report-box__icon text-theme-11"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>
                          <!-- <div class="ml-auto">
                            <div class="<?=$class?>"> <?=(int)$persentase?> % dari bulan sebelumnya <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-up w-4 h-4"><polyline points="18 15 12 9 6 15"></polyline></svg> </div>
                          </div> -->
                        </div>
                        <div class="text-3xl font-bold leading-8 mt-6">74 Komoditas Pasar</div>
                        <div class="text-base text-gray-600 mt-1">Semua Pasar di Banyuwangi</div>
                      </div>
                    </div>
                  </div>
                  <div class="col-span-12 sm:col-span-6 xl:col-span-5 intro-y">
                    <div class="report-box zoom-in">
                      <div class="box p-5">
                        <div class="flex">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user report-box__icon text-theme-11"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>

                        </div>
                        <div class="text-2xl font-bold leading-8 mt-6">32 Pasar Daerah</div>
                        <div class="text-base text-gray-600 mt-1">Seluruh Kabupaten Banyuwangi</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="intro-y chat grid grid-cols-12 gap-5 mt-5">
                    <!-- BEGIN: Chat Side Menu -->
                    <div class="col-span-12 lg:col-span-12 xxl:col-span-12">
                        <div class="intro-y pr-1">
                            <div class="box p-2">
                                <div class="chat__tabs nav-tabs justify-center flex">
                                  <a data-toggle="tab" data-target="#chats" href="javascript:;" class="flex-1 py-2 rounded-md text-center active">View Data</a>
                                  <!-- <a data-toggle="tab" data-target="#friends" href="javascript:;" class="flex-1 py-2 rounded-md text-center">View Tabel</a> -->
                                </div>
                            </div>
                        </div>
                        <div class="tab-content">
                            <div class="tab-content__pane active" id="chats">
                              <div class="intro-y grid grid-cols-12 gap-6 mt-5">
                                <div class="col-span-12 lg:col-span-12">
                                    <!-- BEGIN: Vertical Bar Chart -->
                                    <div class="intro-y box">
                                        <div class="flex flex-col sm:flex-row items-center p-5 border-b border-gray-200">
                                            <h2 class="font-medium text-base mr-auto" id="header_pasar">
                                            Daftar Harga Terupdate Pasar Banyuwangi Hari ini <?=tgl_indo($sekarang);?>
                                            </h2>
                                        </div>
                                        <div class="p-5" id="vertical-bar-chart">
                                            <!-- BEGIN: Responsive Display -->
                                            <div class="row">
                                               <div class="col-md-12 col-lg-12 col-xs-12"> 
                                                <select id="filter_pasar" class="select2 w-full">
                                                    <option value="">Pilih Pasar</option>
                                                    <option data-bulan="semua" data-tahun="semua">Semua Data</option>
                                                    <?php foreach($get_pasar as $data):?>
                                                    <option value="<?=$data->pasar;?>"><?=$data->pasar;?></option>
                                                    <?php endforeach;?>
                                                 </select>
                                               </div>
                                            </div>
                                            
                                            <div class="intro-y box mt-5">
                                            <div class="flex flex-col sm:flex-row items-center p-5 border-b border-gray-200">
                                                        <h6 class="text-center" style="font-style:italic" id="tanggal"></h6>
                                                      </div>
                                                <div class="p-5" id="responsive-slider">
                                                    <div class="preview">
                                                    <div class="slider mx-6 multiple-items">

                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html1"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html2"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html3"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html4"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html5"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html6"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html7"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html8"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html9"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html10"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html11"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html12"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html13"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html14"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html15"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html16"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html17"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html18"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html19"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html20"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html21"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html22"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html23"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html24"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html25"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <div id="html26"></div>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                      </div>
                                                      
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                            <!-- END: Responsive Display -->
                                        </div>
                                    </div>
                                    <!-- END: Vertical Bar Chart -->
                                </div>
                              </div>
                            </div>
                            
                        </div>
                    </div>
                    <!-- END: Chat Side Menu -->
                </div>
            </div>
        <?php $this->load->view('js_evb');?>  
        <?php $this->load->view('js');?>
        