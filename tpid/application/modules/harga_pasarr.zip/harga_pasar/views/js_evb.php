        <script src="<?=base_url();?>assets/js/app-1.js"></script>

        <script>
          $(document).ready(function() {
                  var url = '<?=site_url();?>'
                  $.ajax({
                      url : "harga_pasar/data_pasar",
                      type: "GET",
                      dataType: "JSON",
                      beforeSend:()=>{
                      },
                      success:(data)=>
                      {
                      $('#drop').removeClass('loader');

                      $('#html1').html(data.data);
                            $('#html2').html(data.data2);
                            $('#html3').html(data.data3);
                            $('#html4').html(data.data4);
                            $('#html5').html(data.data5);
                            $('#html6').html(data.data6);
                            $('#html7').html(data.data7);
                            $('#html8').html(data.data8);
                            $('#html9').html(data.data9);
                            $('#html10').html(data.data10);
                            $('#html11').html(data.data11);
                            $('#html12').html(data.data12);
                            $('#html13').html(data.data13);
                            $('#html14').html(data.data14);
                            $('#html15').html(data.data15);
                            $('#html16').html(data.data16);
                            $('#html17').html(data.data17);
                            $('#html18').html(data.data18);
                            $('#html19').html(data.data19);
                            $('#html20').html(data.data20);
                            $('#html21').html(data.data21);
                            $('#html22').html(data.data22);
                            $('#html23').html(data.data23);
                            $('#html24').html(data.data24);
                            $('#html25').html(data.data25);
                            $('#html26').html(data.data26);
                            $('#tanggal').html("*Harga dibandingkan pada tanggal "+data.kemarin);

                      },
                          error:(xhr, status, error)=>{

                              $("#info").html(errorMessage)
                          }
                  });

                  $("#filter_pasar").on("change", function() {
                    $.ajax({
                        url: "harga_pasar/data_pasar",
                        type: "POST",
                        data: {pasar : this.value},
                        dataType: "JSON",
                        beforeSend: () => {
                            $("#info").html(`<span style='font-size:2rem; color:##0335fc;'><strong>Sedang memperbaharui data..</strong></span>`)
                        },
                        success: (data) => {
                            $('#header_pasar').html('Daftar Harga Terupdate '+this.value+' Hari ini '+data.sekarang);
                            $('#html1').html(data.data);
                            $('#html2').html(data.data2);
                            $('#html3').html(data.data3);
                            $('#html4').html(data.data4);
                            $('#html5').html(data.data5);
                            $('#html6').html(data.data6);
                            $('#html7').html(data.data7);
                            $('#html8').html(data.data8);
                            $('#html9').html(data.data9);
                            $('#html10').html(data.data10);
                            $('#html11').html(data.data11);
                            $('#html12').html(data.data12);
                            $('#html13').html(data.data13);
                            $('#html14').html(data.data14);
                            $('#html15').html(data.data15);
                            $('#html16').html(data.data16);
                            $('#html17').html(data.data17);
                            $('#html18').html(data.data18);
                            $('#html19').html(data.data19);
                            $('#html20').html(data.data20);
                            $('#html21').html(data.data21);
                            $('#html22').html(data.data22);
                            $('#html23').html(data.data23);
                            $('#html24').html(data.data24);
                            $('#html25').html(data.data25);
                            $('#html26').html(data.data26);
                            $('#tanggal').html("*Harga dibandingkan pada tanggal "+data.kemarin);
                        },
                        error: (xhr, status, error) => {
                            $("#info").html(errorMessage)
                        }
                    });
                  });
          })
        </script>
        
        