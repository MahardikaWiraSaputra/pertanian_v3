<!-- BEGIN: Content -->
<div class="content">
                <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
                    <h2 class="text-lg font-medium mr-auto">
                      Informasi Harga Pasar
                    </h2>
                </div>

                <div class="grid grid-cols-12 gap-6 mt-5">
                  <div class="col-span-12 sm:col-span-6 xl:col-span-7 intro-y">
                    <div class="report-box zoom-in">
                      <div class="box p-5">
                        <div class="flex">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-credit-card report-box__icon text-theme-11"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>
                          <!-- <div class="ml-auto">
                            <div class="<?=$class?>"> <?=(int)$persentase?> % dari bulan sebelumnya <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-up w-4 h-4"><polyline points="18 15 12 9 6 15"></polyline></svg> </div>
                          </div> -->
                        </div>
                        <div class="text-3xl font-bold leading-8 mt-6">74 Komoditas Pasar</div>
                        <div class="text-base text-gray-600 mt-1">Semua Pasar di Banyuwangi</div>
                      </div>
                    </div>
                  </div>
                  <div class="col-span-12 sm:col-span-6 xl:col-span-5 intro-y">
                    <div class="report-box zoom-in">
                      <div class="box p-5">
                        <div class="flex">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user report-box__icon text-theme-11"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>

                        </div>
                        <div class="text-2xl font-bold leading-8 mt-6">32 Pasar Daerah</div>
                        <div class="text-base text-gray-600 mt-1">Seluruh Kabupaten Banyuwangi</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="intro-y chat grid grid-cols-12 gap-5 mt-5">
                    <!-- BEGIN: Chat Side Menu -->
                    <div class="col-span-12 lg:col-span-12 xxl:col-span-12">
                        <div class="intro-y pr-1">
                            <div class="box p-2">
                                <div class="chat__tabs nav-tabs justify-center flex">
                                  <a data-toggle="tab" data-target="#chats" href="javascript:;" class="flex-1 py-2 rounded-md text-center active">View Data</a>
                                  <!-- <a data-toggle="tab" data-target="#friends" href="javascript:;" class="flex-1 py-2 rounded-md text-center">View Tabel</a> -->
                                </div>
                            </div>
                        </div>
                        <div class="tab-content">
                            <div class="tab-content__pane active" id="chats">
                              <div class="intro-y grid grid-cols-12 gap-6 mt-5">
                                <div class="col-span-12 lg:col-span-12">
                                    <!-- BEGIN: Vertical Bar Chart -->
                                    <div class="intro-y box">
                                        <div class="flex flex-col sm:flex-row items-center p-5 border-b border-gray-200">
                                            <h2 class="font-medium text-base mr-auto">
                                            Daftar Harga Terupdate Pasar Banyuwangi Hari ini
                                            </h2>
                                        </div>
                                        <div class="p-5" id="vertical-bar-chart">
                                            <!-- BEGIN: Responsive Display -->
                                            <div class="row">
                                               <div class="col-md-12 col-lg-12 col-xs-12"> 
                                                <select id="filter_bulan" class="select2 w-full">
                                                    <option value="">Pilih Pasar</option>
                                                    <option data-bulan="semua" data-tahun="semua">Semua Data</option>
                                                    <?php foreach($get_pasar as $data):?>
                                                    <option value="<?=$data->pasar;?>"><?=$data->pasar;?></option>
                                                    <?php endforeach;?>
                                                 </select>
                                               </div>
                                            </div>
                                            
                                            <div class="intro-y box mt-5">
                                                <div class="p-5" id="responsive-slider">
                                                    <div class="preview">
                                                    <div class="slider mx-6 multiple-items">
                                                        <div class="col-md-6 col-lg-12 col-xs-12 px-2">
                                                          <?php $get_1 = array_slice($harga_pasar,0,3);
                                                          foreach($get_1 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?> 
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                          <?php $get_2 = array_slice($harga_pasar,3,3);
                                                          foreach($get_2 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?> 
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                          <?php $get_3 = array_slice($harga_pasar,6,3);
                                                          foreach($get_3 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_4 = array_slice($harga_pasar,9,3);
                                                          foreach($get_4 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_5 = array_slice($harga_pasar,12,3);
                                                          foreach($get_5 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_6 = array_slice($harga_pasar,15,3);
                                                          foreach($get_6 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_7 = array_slice($harga_pasar,18,3);
                                                          foreach($get_7 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_8 = array_slice($harga_pasar,21,3);
                                                          foreach($get_8 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_9 = array_slice($harga_pasar,23,3);
                                                          foreach($get_9 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_10 = array_slice($harga_pasar,26,3);
                                                          foreach($get_10 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_10 = array_slice($harga_pasar,29,3);
                                                          foreach($get_10 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_11 = array_slice($harga_pasar,32,3);
                                                          foreach($get_11 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_12 = array_slice($harga_pasar,35,3);
                                                          foreach($get_12 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_14 = array_slice($harga_pasar,38,3);
                                                          foreach($get_14 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_15 = array_slice($harga_pasar,41,3);
                                                          foreach($get_15 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_16 = array_slice($harga_pasar,44,3);
                                                          foreach($get_16 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_17 = array_slice($harga_pasar,47,3);
                                                          foreach($get_17 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_18 = array_slice($harga_pasar,50,3);
                                                          foreach($get_18 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_19 = array_slice($harga_pasar,53,3);
                                                          foreach($get_19 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_20 = array_slice($harga_pasar,56,3);
                                                          foreach($get_20 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_21 = array_slice($harga_pasar,59,3);
                                                          foreach($get_21 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_22 = array_slice($harga_pasar,62,3);
                                                          foreach($get_22 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_23 = array_slice($harga_pasar,65,3);
                                                          foreach($get_23 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_24 = array_slice($harga_pasar,68,3);
                                                          foreach($get_24 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div class="col-md-6 col-xs-12 col-lg-12 px-2">
                                                        <?php $get_25 = array_slice($harga_pasar,71,3);
                                                          foreach($get_25 as $data): ?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-12">
                                                            <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y mt-5">
                                                              <div class="report-box zoom-in">
                                                                  <div class="box p-5 heg">
                                                                      <div class="flex">
                                                                          <img src="<?=$data->gambar?>" style="height: 60px;"> 
                                                                          <div class="ml-autop">
                                                                              <div class="text-22xl font-bold"><?=$data->KET;?></div>
                                                                              <div class="text-base text-gray-600 mt-1">Harga Rp.<?=format($data->harga).'/'.$data->satuan;?></div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <?php endforeach;?>
                                                          <div class="col-md-6 col-sm-12 h-32 mt-5" style="visibility:hidden">
                                                            <div class="h-full bg-gray-200 dark:bg-dark-1 rounded-md">
                                                              <h3 class="h-full font-medium flex items-center justify-center text-22xl">1</h3>
                                                            </div>
                                                          </div>
                                                        </div>
                                                      </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- END: Responsive Display -->
                                        </div>
                                    </div>
                                    <!-- END: Vertical Bar Chart -->
                                </div>
                              </div>
                            </div>
                            <div class="tab-content__pane" id="friends">
                              <div class="intro-y grid grid-cols-12 gap-6 mt-5">
                                <div class="col-span-12 lg:col-span-12">
                                    <!-- BEGIN: Vertical Bar Chart -->
                                    <div class="intro-y box">
                                        <div class="flex flex-col sm:flex-row items-center p-5 border-b border-gray-200">
                                            <h2 class="font-medium text-base mr-auto">
                                                Tabel Alokasi Dana Berdasarkan Desa
                                            </h2>
                                            
                                        </div>
                                        <!-- BEGIN: Datatable -->
                                        <div class="intro-y datatable-wrapper box p-5 mt-5 table-responsive">
                                            <table id="tabel_data" class="table table-report table-report--bordered display datatable w-full">
                                                <thead>
                                                    <tr>
                                                        <th class="border-b-2 whitespace-no-wrap">Desa</th>
                                                        <th class="border-b-2 text-left whitespace-no-wrap">Kecamatan</th>
                                                        <th class="border-b-2 text-center whitespace-no-wrap">Alokasi Dana</th>
                                                        <th class="border-b-2 text-center whitespace-no-wrap">Total Penyerapan</th>
                                                        <th class="border-b-2 text-center whitespace-no-wrap">Detail</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php foreach($by_desa as $data):?>
                                                    <tr>
                                                        <td class="border-b">
                                                            <div class="font-medium whitespace-no-wrap"><?=$data->desa?></div>
                                                        </td>
                                                        <td class="text-left border-b"><?=$data->kecamatan?></td>
                                                        <td class="text-center border-b"><?=format($data->total)?></td>
                                                        <td class="text-center border-b"><?=format($data->total)?></td>
                                                        <td class="border-b w-5">
                                                            <div class="flex sm:justify-center items-center">
                                                                <a onclick="modal_by_desa('<?=$data->desa?>','<?=$data->total?>')" href="javascript:;" data-toggle="modal" data-target="#header-footer-modal-preview" class="button w-32 mr-2 mb-2 flex items-center justify-center bg-theme-1 text-white"><i data-feather="activity" class="w-4 h-4 mr-2"></i> Detail </a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach;?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <!-- END: Datatable -->
                                    </div>
                                    
                                    <!-- END: Vertical Bar Chart -->
                                </div>

                              </div>

                            </div>
                        </div>
                    </div>
                    <!-- END: Chat Side Menu -->
                </div>
            </div>
            <!-- BEGIN::MODAL-->
             <div class="modal" id="header-footer-modal-preview">
               <div class="modal__content modal__content--xl backdrop_modal">
                 <h2 id="modal_title" class="font-medium text-base mt-5 mr-5 text-center" style="text-transform:uppercase;font-weight:bold">Grafik Pendaftar kartu kuning di kecamatan Banyuwangi</h2>
                   <div class="p-5 grid grid-cols-12 gap-1 row-gap-1">
                     <div class="col-span-12 sm:col-span-6 lg:col-span-8 col-xs-12">
                       <div class="intro-y">
                         <!-- <h2 class="text-lg font-medium truncate mr-5">
                             Pendidikan Terakhir
                         </h2> -->
                       </div>
                       <div id="chart-container">
                       </div>

                     </div>
                     <div class="col-span-12 sm:col-span-6 lg:col-span-4 col-xs-12">
                       <div class="intro-y">
                         <!-- <h2 class="text-lg font-medium truncate mr-5">
                             Pendidikan Terakhir
                         </h2> -->
                       </div>
                       <div id="chart-container1">
                       <div class="intro-y box p-5 bg-theme-7 text-white">
                            <div class="flex items-center">
                                <div class="font-medium text-lg">Jumlah Alokasi Dana Desa</div>
                            </div>
                            <!-- <div class="mt-4">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</div> -->
                            <div class="font-medium flex mt-5">
                                <button id="alokasi" type="button" class="button button--sm" style="color: white;font-weight: bold;font-size: 22px;text-shadow: 2px 2px #000000;">189.000.000</button>
                                <!-- <button type="button" class="button button--sm ml-autop">Dismiss</button> -->
                            </div>
                        </div>
                       </div>
                       <div id="chart-container3" class="mt-5 ml-auto">
                       <div class="intro-y box p-5 bg-theme-7 text-white">
                            <div class="flex items-center">
                                <div class="font-medium text-lg">Jumlah Alokasi Dana desa terserap</div>
                                <!-- <div class="text-xs bg-white text-gray-800 px-1 rounded-md ml-auto">New</div> -->
                            </div>
                            <!-- <div class="mt-4">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</div> -->
                            <div class="font-medium flex mt-5">
                                <button id="penyerapan" type="button" class="button button--sm" style="color: white;font-weight: bold;font-size: 22px;text-shadow: 2px 2px #000000;">189.000.000</button>
                                <!-- <button type="button" class="button button--sm ml-auto">Dismiss</button> -->
                            </div>
                        </div>
                       </div>
                     </div>
                   </div>
                 </div>
              </div>
              <div class="modal" id="header-footer-modal-preview-new">
                <div class="modal__content modal__content--xl backdrop_modal">
                    <h2 id="modal_title_detail" class="font-medium text-base mt-5 mr-5 text-center" style="text-transform:uppercase;font-weight:bold">Grafik Pendaftar kartu kuning di kecamatan Banyuwangi</h2>
                    <div class="p-5 grid grid-cols-12 gap-1 row-gap-1">
                      <div class="col-span-12 sm:col-span-6 lg:col-span-6 col-xs-12">
                          <div class="intro-y">
                          </div>
                          <div id="chart-container_desa">
                          </div>
                      </div>
                      <div class="col-span-12 sm:col-span-6 lg:col-span-6 col-xs-12">
                          <div class="intro-y">
                          </div>
                          <div id="chart-container_desa1">
                            
                          </div>
                          <div id="chart-container3" class="mt-5 ml-auto">
                            
                          </div>
                      </div>
                    </div>
                </div>
              </div>
        <?php $this->load->view('js');?>
        <?php $this->load->view('js_evb');?>